---
icon: fas fa-code
---

Исходный код проекта находится тут:

[https://github.com/malikzh/NCANode](https://github.com/malikzh/NCANode)

## Багрепорты

Сообщить о баге можно здесь: 

[https://github.com/malikzh/NCANode/issues](https://github.com/malikzh/NCANode/issues)

Я обязательно рассмотрю, как будет время :)

## Пулл-реквесты

Если Вы сделали доработку, то можете отправлять пулл реквест сюда:

[https://github.com/malikzh/NCANode/pulls](https://github.com/malikzh/NCANode/pulls)
