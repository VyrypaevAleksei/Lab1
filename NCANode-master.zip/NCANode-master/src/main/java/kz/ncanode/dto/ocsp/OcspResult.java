package kz.ncanode.dto.ocsp;

public enum OcspResult {
    UNKOWN,
    ACTIVE,
    REVOKED
}
