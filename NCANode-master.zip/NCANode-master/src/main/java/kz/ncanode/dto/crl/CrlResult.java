package kz.ncanode.dto.crl;

public enum CrlResult {
    REVOKED,
    ACTIVE
}
