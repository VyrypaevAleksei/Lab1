package kz.ncanode.dto.certificate;

public enum CertificateRevocation {
    OCSP,
    CRL,
}
